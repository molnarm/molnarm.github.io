=== Igemutató ===
Contributors: molnarm
Tags: bible, biblia, szentírás, tooltip
Requires at least: 2.7
Tested up to: 3.9
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Az oldal tartalmában található szentírási hivatkozásokat jeleníti meg felugró szövegbuborékban

== Description ==
Az oldal tartalmában található szentírási hivatkozásokat jeleníti meg felugró szövegbuborékban. Beállítható a használni kívánt fordítás, a szöveg betűmérete, a felugró ablak mérete és időzítése.

A bővítmény a szentiras.hu API-ját használja.

== Installation ==

A bővítmény bekapcsolása után működőképes. Ha a beállításokon szeretnénk változtatni, a Beállítások / Igemutató oldalon tehetjük meg.

== Frequently Asked Questions ==
http://molnarm.github.io/igemutato/